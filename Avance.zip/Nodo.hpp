#pragma once
template <class T>
class CNodo {
public:
	T e;
	CNodo<T>* sig;
	CNodo(T e, CNodo<T>* sig = nullptr) : e(e), sig(sig) {}
};
