#pragma once
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include "CArbol.hpp"

using namespace std;

class Paciente {
public:
	string nombre, seguro, estado;
	int edad, dni;
	Paciente(string nombre, string seguro, string estado, int edad, int dni) {
		this->nombre = nombre;
		this->seguro = seguro;
		this->estado = estado;
		this->edad = edad;
		this->dni = dni;
	}
};

class Input {
private:
	
	ifstream archivo;
	string cadena;
public:
	vector<Paciente*> pacientes;
	Arbol_B<Paciente*>* nombres;
	Arbol_B<Paciente*>* seguros;
	Arbol_B<Paciente*>* estados;
	Arbol_B<Paciente*>* edades;
	Arbol_B<Paciente*>* DNIs;
	Input() { 
		nombres = new Arbol_B<Paciente*>(); 
		seguros = new Arbol_B<Paciente*>();
		estados = new Arbol_B<Paciente*>();
		edades = new Arbol_B<Paciente*>();
		DNIs = new Arbol_B<Paciente*>();
	}

	void indexar(Paciente* obj) {
		auto compNombre = [=](Paciente* a, Paciente* b)->bool {return (a->nombre.compare(b->nombre)) < 0; };
		auto compSeguro = [=](Paciente* a, Paciente* b)->bool {return (a->seguro.compare(b->seguro)) < 0; };
		auto compEstado = [=](Paciente* a, Paciente* b)->bool {return (a->estado.compare(b->estado)) < 0; };
		auto compEdad = [=](Paciente* a, Paciente* b)->bool {return a->edad < b->edad; };
		auto compDNI = [=](Paciente* a, Paciente* b)->bool {return a->dni < b->dni; };

		nombres->insertar(obj, compNombre);
		seguros->insertar(obj, compSeguro);
		estados->insertar(obj, compSeguro);
		edades->insertar(obj, compEdad);
		DNIs->insertar(obj, compDNI);
	}

	void lectura(string nombre, bool cabecera = true){
		archivo.open(nombre);
		if(cabecera){
			getline(archivo, cadena);
		}
		while (getline(archivo, cadena)) {
			stringstream ss(cadena);
			
		}
	}


};
