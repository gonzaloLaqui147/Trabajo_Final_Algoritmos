/*

#ifndef __HASHTABLA_HPP__
#define __HASHTABLA_HPP__
#include <iostream>
#include "HashEntidad.hpp"

template <class T>
class HashTabla {
private:
	HashEntidad<T> ** tabla;
	int numElementos;
	int TABLE_SIZE;

public:
	HashTabla(int TABLE_SIZE = 128) {
		this->TABLE_SIZE = TABLE_SIZE;
		tabla = new HashEntidad<T>*[TABLE_SIZE];
		for (int i = 0; i < TABLE_SIZE; ++i) {
			tabla[i] = nullptr;
		}
		numElementos = 0;
	}
	~HashTabla()
	{
		for (int i = 0; i < TABLE_SIZE; ++i) {
			if (tabla[i] != nullptr) {
				delete tabla[i];
			}
		}
		delete[] tabla;
	}

	//Direccionamiento seg�n Prueba Lineal
	void insertar(int key, T value) {
		//Hash prima
		int base, step, hash;
		//validar si la tabla est� llena
		if (numElementos == TABLE_SIZE)return;
		//Funci�n Hash1
		base = key%TABLE_SIZE;
		hash = base;
		//constante para Hash2
		step = 0;
		while (tabla[hash]!=nullptr)
		{
			//Funci�n Hash2
			hash = (base + step) % TABLE_SIZE;
			step++;
		}
		//almacenarlo en la tabla
		tabla[hash] = new HashEntidad<T>(key,value);
		numElementos++;
	}
	int size() {
		return TABLE_SIZE;
	}
	int sizeactual() {
		return numElementos;
	}
	int buscar(int key) {
		int step = 0;
		int i, base;
		i = base = key%TABLE_SIZE; //hash1 es = a hash2 cuando step=0;
		while (true)
		{
			if (tabla[i] == nullptr)return -1;
			else if(tabla[i]->getKey()==key) {
				return i;
			}
			else step++;

			i = (base + step) % TABLE_SIZE;
		}
	}
	T buscar_2(int key) {
		int step = 0;
		int i, base;
		i = base = key%TABLE_SIZE; //hash1 es = a hash2 cuando step=0;
		while (true)
		{
			if (tabla[i] == nullptr)return nullptr;
			else if (tabla[i]->getKey() == key) {
				return tabla[i]->getValue();
			}
			else step++;

			i = (base + step) % TABLE_SIZE;
		}
	}
};


#endif // !__HASHTABLA_HPP__


*/

