#pragma once
#include "Nodo.hpp"
#include <functional>
#include <iostream>

using namespace std;

template <class T>
class CLista {
private:
	CNodo<T>* inicio;
	int tam;
public:
	CLista() { tam = 0; inicio = nullptr; }

	void insertar(T e) {
		CNodo<T>* nuevo = new CNodo<T>(e);
		if (inicio == nullptr) { inicio = nuevo; }
		else {
			CNodo<T>* aux = inicio;
			for (int i = 1; i < tam; i++) {
				aux = aux->sig;
			}
			aux->sig = nuevo;
		}
		tam++;
	}

	void mostrar(function<void(T)> criterio_i) {
		CNodo<T>* aux = inicio;
		for (int i = 0; i < tam; i++) {
			criterio_i(aux->e);
			aux = aux->sig;
		}
	}
};
