#include <functional>

using namespace std;

template <class G>
class Arbol_B {
private:
	int cantidad;
	template <class G>
	class Nodo {
	public:
		Nodo<G>* izquierda;
		Nodo<G>* derecha;
		G valor;
		Nodo(G valor) : valor(valor) { izquierda = derecha = nullptr; }
	};
	Nodo<G>* raiz;

	void _insertar(Nodo<G>*& nodo, G& valor, function<bool(G, G)> criterio) {
		if (nodo == nullptr) {
			nodo = new Nodo<G>(valor);
			cantidad++;
		}
		else {
			if (criterio(valor, nodo->valor)) {
				_insertar(nodo->izquierda, valor, criterio);
			}
			else {
				_insertar(nodo->derecha, valor, criterio);
			}
		}
	}

	void _buscar(Nodo<G>* nodo, G valor, bool& encontrado, function<bool(G, G)> criterio, function<bool(G, G)> menor, function<void(G)> criterio_impresion) {
		if (nodo == nullptr) {
			encontrado = false;
		}
		else {
			if (criterio(valor, nodo->valor)) {
				criterio_impresion(nodo->valor);
				encontrado = true; return;

			}
			else {
				if (menor(valor, nodo->valor)) {
					_buscar(nodo->izquierda, valor, encontrado, criterio, menor, criterio_impresion);
				}
				else {
					_buscar(nodo->derecha, valor, encontrado, criterio, menor, criterio_impresion);
				}
			}
		}
	}


	void _mostrar_Criterio(Nodo<G>* nodo, G valor, function<bool(G, G)> compara, function<void(G)> criterio_impresion) {
		if (nodo == nullptr) { return; }
		else {

			if (compara(valor, nodo->valor)) {
				criterio_impresion(nodo->valor);
			}
			else {
				cout << "   -   " << endl;
			}
			_mostrar_Criterio(nodo->izquierda, valor, compara, criterio_impresion);
			_mostrar_Criterio(nodo->derecha, valor, compara, criterio_impresion);
		}
	}

	void en_Orden(Nodo<G>* nodo, function<void(G)> criterio_impresion) {
		if (nodo == nullptr) return;
		else {
			en_Orden(nodo->izquierda, criterio_impresion);
			criterio_impresion(nodo->valor);
			en_Orden(nodo->derecha, criterio_impresion);
		}
	}

	void pre_Orden(Nodo<G>* nodo, function<void(G)> criterio_impresion) {
		if (nodo == nullptr) return;
		else {
			criterio_impresion(nodo->valor);
			en_Orden(nodo->izquierda, criterio_impresion);
			en_Orden(nodo->derecha, criterio_impresion);
		}
	}

	void borrar_todo(Nodo<G>*& nodo) {
		if (nodo != nullptr) {
			borrar_todo(nodo->izquierda);
			borrar_todo(nodo->derecha);
			delete nodo;
		}
	}

public:
	Arbol_B() {
		raiz = nullptr; cantidad = 0;
	}
	void insertar(G v, function<bool(G, G)> criterio) {
		_insertar(raiz, v, criterio);
	}
	bool buscar(G v, function<bool(G, G)> criterio, function<bool(G, G)> menor, function<void(G)> criterio_impresion) {
		bool encontrado = false;
		_buscar(raiz, v, encontrado, criterio, menor, criterio_impresion);
		return encontrado;
	}

	void borrar() {
		borrar_todo(raiz);
	}
	void En_Orden(function<void(G)> criterio_i) {
		en_Orden(raiz, criterio_i);
	}
	void Pre_Orden(function<void(G)> criterio_i) {
		pre_Orden(raiz, criterio_i);
	}
	void mostrar_Criterio(G v, function<bool(G, G)> comp, function<void(G)> criterio_impresion) {
		_mostrar_Criterio(raiz, v, comp, criterio_impresion);
	}
};