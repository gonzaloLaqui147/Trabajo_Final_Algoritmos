#pragma once
#include <iostream>
#include <string>
#include "Data.hpp"
#include "HashTabla.hpp"

using namespace std;

Input* obj_Input = new Input();

auto imprimir = [](Paciente* obj) {
	cout << obj->nombre << "\t" << obj->seguro << "\t" << obj->estado << "\t" << obj->edad << "\t" << obj->dni << endl;
};

void menu() {
	//cout << "1. Crear Tabla" << endl;
	cout << "2. Mostrar Tabla" << endl;
	cout << "3. Insertar Paciente" << endl;
	cout << "4. Filtrado de Datos" << endl;
	cout << "5. Ordenar columnas" << endl;
	cout << "6. Exportar Tabla" << endl;
	cout << "7. Salir" << endl;
}

string crear_Tabla() {
	string nombre_tabla;

	cout << "Ingrese el nombre de la nueva tabla: "; cin >> nombre_tabla; cout << endl << endl;

	cout << "Usted ha creado una nueva tabla con el nombre: " << nombre_tabla;

	return nombre_tabla;
}

void mostrar_tabla(vector<int> keys, HashTabla<Paciente*>* ht) {
	Paciente* tmp;
	for (int i = 0; i < keys.size(); i++) {
		tmp = ht->buscarV(keys.at(i));
		imprimir(tmp);
	}
	cout << endl << endl;
}

void insertar_Paciente(Paciente*& temp) {
	
	string nombre, seguro, estado;
	int edad, dni;
	cout << "Complete los siguientes datos: " << endl;
	cout << "Nombre: "; cin >> nombre; cout << endl;
	cout << "Seguro (si no cuenta con uno, ingrese 'Ninguno'): "; cin >> seguro; cout << endl;
	cout << "Estado Covid-19 (Positivo o Negativo): "; cin >> estado; cout << endl;
	cout << "Edad: "; cin >> edad; cout << endl;
	cout << "DNI: "; cin >> dni; cout << endl;

	temp = new Paciente(nombre, seguro, estado, edad, dni);

	obj_Input->indexar(temp);
}

void filtrar_Datos() {
	
	int filtrado;
	cout << "1.Filtrar por Nombre" << endl;
	cout << "2.Filtrar por Seguro" << endl;
	cout << "3.Filtrar por Estado" << endl;
	cout << "4.Filtrar por Edad" << endl;
	cout << "5.Filtrar por DNI" << endl;
	cin >> filtrado;
	switch (filtrado)
	{
	case 1:
		obj_Input->nombres->En_Orden(imprimir);
		break;
	case 2:
		obj_Input->seguros->En_Orden(imprimir);
		break;
	case 3:
		obj_Input->estados->En_Orden(imprimir);
		break;
	case 4:
		obj_Input->edades->En_Orden(imprimir);
		break;
	case 5:
		obj_Input->DNIs->En_Orden(imprimir);
		break;
	default:
		break;
	}
}