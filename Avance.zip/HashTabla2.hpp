#pragma once
#include <iostream>
#include <vector>
#include <sstream>
#include "HashEntidad.hpp"

using namespace std;

template <class T>
class HashTabla {
private:
	HashEntidad<T> ** tabla;
	vector<HashEntidad<T>*> tabla_v;
	int numElementos;
	int TABLE_SIZE;

public:
	/*HashTabla(int TABLE_SIZE = 128) {
		this->TABLE_SIZE = TABLE_SIZE;
		tabla = new HashEntidad<T>*[TABLE_SIZE];
		for (int i = 0; i < TABLE_SIZE; ++i) {
			tabla[i] = nullptr;
		}
		numElementos = 0;
	}*/

	HashTabla(){
		numElementos = 0;
		TABLE_SIZE = 20;
		for (int i = 0; i < 20; i++) {
			tabla_v.push_back(NULL);
		}
	}

	~HashTabla()
	{
		for (int i = 0; i < TABLE_SIZE; ++i) {
			if (tabla[i] != nullptr) {
				delete tabla[i];
			}
		}
		delete[] tabla;
	}

	//Direccionamiento seg�n Prueba Lineal
	void insertar(int key, T value) {
		//Hash prima
		int base, step, hash;
		//validar si la tabla est� llena
		if (numElementos == TABLE_SIZE)return;
		//Funci�n Hash1
		base = key%TABLE_SIZE;
		hash = base;
		//constante para Hash2
		step = 0;
		while (tabla[hash] != nullptr)
		{
			//Funci�n Hash2
			hash = (base + step) % TABLE_SIZE;
			step++;
		}
		//almacenarlo en la tabla
		tabla[hash] = new HashEntidad<T>(key, value);
		numElementos++;
	}

	void insertarV(int key, T value) {
		
		int base, step, hash;
		if (numElementos == tabla_v.size()) return;
		base = key%TABLE_SIZE;
		hash = base;
		step = 0;
		while (tabla_v.at(hash) != nullptr)
		{
			hash = (base + step) % TABLE_SIZE;
			step++;
		}
		numElementos++;
		HashEntidad<T>* temp = new HashEntidad<T>(key, value);
		tabla_v.at(hash) = temp;
	}

	int size() {
		return TABLE_SIZE;
	}
	int sizeactual() {
		return numElementos;
	}
	int buscar(int key) {
		int step = 0;
		int i, base;
		i = base = key%TABLE_SIZE; //hash1 es = a hash2 cuando step=0;
		while (true)
		{
			if (tabla[i] == nullptr)return -1;
			else if (tabla[i]->getKey() == key) {
				return i;
			}
			else step++;

			i = (base + step) % TABLE_SIZE;
		}
	}

	T buscarV(int key) {
		int step = 0;
		int i, base;
		i = base = key%TABLE_SIZE; //hash1 es = a hash2 cuando step=0;
		while (true)
		{
			//if (tabla[i] == nullptr)return -1;
			if (tabla_v.at(i)->getKey() == key) {
				return tabla_v.at(i)->getValue();
			}
			else step++;

			i = (base + step) % TABLE_SIZE;
		}
	}
};
