#include "HashTabla2.hpp"
#include "HashEntidad.hpp"
#include "CLista.hpp"
#include "Interfaz.hpp"

using namespace System;


void imprimirTablaHash(HashTabla<int> *ht,int*keys) {
	cout << "SIZE TABLA: " << ht->size()<<endl;
	cout << "SIZE ACTUAL: " << ht->sizeactual() << endl;
	for (int i = 0; i < ht->size(); ++i) {
		cout << ht->buscar(keys[i])<< " : " <<keys[i] << endl;
	}
}

//void imprimirH(HashTabla<CLista<int>*> *ht, int*keys) {
//	cout << "SIZE TABLA: " << ht->size() << endl;
//	cout << "SIZE ACTUAL: " << ht->sizeactual() << endl;
//	CLista<int>* objTemporal;
//	for (int i = 0; i < ht->size(); ++i) {
//		//cout << ht->buscar(keys[i]) << " : " << keys[i] << endl;
//		cout << keys[i] << " : ";
//		objTemporal = ht->buscar_2(keys[i]);
//		if (objTemporal != nullptr) { objTemporal->mostrar(imprimir); cout << endl << endl; }
//		else { cout << "Objeto sin valor" << endl << endl; }
//		
//	}
//}



int main() {
	/*HashTabla<int> *ht = new HashTabla<int>(9);
	int keys[] = {6,34,67,92,8,5,3,2,15};
	ht->insertar(6, 60);
	ht->insertar(34, 340);
	ht->insertar(67, 160);
	ht->insertar(92, 360);
	ht->insertar(8, 120);
	ht->insertar(5, 452);
	ht->insertar(3, 422);
	ht->insertar(2, 952);
	ht->insertar(15, 752);*/
	int op = 0;
	/*
	CLista<int>* objL = new CLista<int>();
	CLista<int>* objL2 = new CLista<int>();

	HashTabla<CLista<int>*> *ht = new HashTabla<CLista<int>*>(4);
	int keys[] = { 6,34,67,92,8,5,3,2,15 };
	
	//---------------------
	objL->insertar(60);
	objL->insertar(340);
	objL->insertar(160);
	objL->insertar(360);

	//---------------------
	objL2->insertar(50);
	objL2->insertar(70);
	objL2->insertar(90);
	objL2->insertar(110);
	//---------------------

	ht->insertar(6, objL);
	ht->insertar(34, objL2);

	imprimirH(ht, keys);
	
	//imprimirTablaHash(ht, keys);
	*/
	Random r; int val;
	vector<string> nombre_tabla;
	vector<int> keys;
	Paciente* obj;
	HashTabla<Paciente*>* ht = new HashTabla<Paciente*>();
	
	do {
		menu();
		cin >> op;
		switch (op) {
		case 1:
			crear_Tabla();
			break;
		case 2:
			mostrar_tabla(keys, ht);
			break;
		case 3:
			val = r.Next(100, 999);
			keys.push_back(val);
			insertar_Paciente(obj);
			ht->insertarV(val, obj);
			break;
		case 4:
			filtrar_Datos();
			break;
		default:
			break;
		}
	} while (op != 7);

	cin.get();

	return 0;
}


//------------ 11/06/2020 ------------//
/*
+ En el caso de vectores inicializar espacios con nullptr en HashTabla 2do Constructor

Filtrar:

+ Implementar funcion buscar_Columna() en el driver -> Recorrer cada nodo de una lista para hallar la columna deseada

+

Archivos:

+ Se debe implementar lectura y escritura

*/
