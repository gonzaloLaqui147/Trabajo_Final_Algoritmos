#ifndef __HASHENTIDAD_HPP__
#define __HASHENTIDAD_HPP__

template <class T>
class HashEntidad {
private:	
	int key;
	T value;
public:
	HashEntidad(int key, T value) {
		this->key = key;
		this->value = value;
	}
	int getKey() { return key; }
	T getValue() { return value; }
};

#endif // !__HASHENTIDAD_HPP__

